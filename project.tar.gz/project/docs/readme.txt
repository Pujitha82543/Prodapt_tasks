Linux Mission Impossible
