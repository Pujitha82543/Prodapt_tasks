class CartService:

    def checkout(self, user):

        print("\nCheckout Successful")

        user.cart.view_cart()

        print("Amount to Pay : ₹", user.cart.calculate_total())