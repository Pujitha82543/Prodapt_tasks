class Product:
    def __init__(self, name, price, stock):
        self.__name = name
        self.__price = price
        self.__stock = stock

    # Getters
    def get_name(self):
        return self.__name

    def get_price(self):
        return self.__price

    def get_stock(self):
        return self.__stock

    # Setter
    def set_stock(self, stock):
        self.__stock = stock

    def __str__(self):
        return f"{self.__name} - ₹{self.__price} (Stock: {self.__stock})"
    