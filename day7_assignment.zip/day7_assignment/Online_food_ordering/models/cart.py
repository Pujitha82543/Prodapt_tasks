from exceptions.cart_exceptions import OutOfStockError, ProductNotFoundError


class Cart:

    def __init__(self):
        self.items = {}

    def add_product(self, product, quantity):

        if quantity > product.get_stock():
            raise OutOfStockError("Not enough stock available.")

        if product in self.items:
            self.items[product] += quantity
        else:
            self.items[product] = quantity

        product.set_stock(product.get_stock() - quantity)

    def remove_product(self, product):

        if product not in self.items:
            raise ProductNotFoundError("Product not found in cart.")

        quantity = self.items.pop(product)

        product.set_stock(product.get_stock() + quantity)

    def view_cart(self):

        total = 0

        print("\n------ CART ------")

        if len(self.items) == 0:
            print("Cart is empty.")

        for product, qty in self.items.items():

            subtotal = product.get_price() * qty
            total += subtotal

            print(f"{product.get_name()} x {qty} = ₹{subtotal}")

        print("------------------")
        print("Total = ₹", total)

    def calculate_total(self):

        total = 0

        for product, qty in self.items.items():
            total += product.get_price() * qty

        return total