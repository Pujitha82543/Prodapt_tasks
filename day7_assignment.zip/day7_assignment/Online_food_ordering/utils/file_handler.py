def save_order(cart):

    with open("data/order_history.txt", "a") as file:

        file.write("\n")

        for product, qty in cart.items.items():

            file.write(f"{product.get_name()} x {qty}\n")