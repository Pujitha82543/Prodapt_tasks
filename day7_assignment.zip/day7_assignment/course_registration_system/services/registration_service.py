from utils.file_handler import read_csv, write_csv
from exceptions.custom_exceptions import *

COURSE_FILE = "data/courses.csv"
STUDENT_FILE = "data/students.csv"


class RegistrationService:

    def view_courses(self):

        courses = read_csv(COURSE_FILE)

        for c in courses:
            print("------------------------")
            print("Course ID :", c["course_id"])
            print("Course Name :", c["course_name"])
            print("Instructor :", c["instructor"])
            print("Seats Available :", c["seats_available"])

    def add_course(self):

        cid = input("Course ID : ")
        cname = input("Course Name : ")
        instructor = input("Instructor : ")
        seats = input("Seats : ")

        courses = read_csv(COURSE_FILE)

        courses.append({
            "course_id": cid,
            "course_name": cname,
            "instructor": instructor,
            "seats_available": seats
        })

        write_csv(
            COURSE_FILE,
            ["course_id", "course_name", "instructor", "seats_available"],
            courses
        )

        print("Course added successfully")

    def register_student(self):

        sid = input("Student ID : ")
        name = input("Name : ")
        email = input("Email : ")

        students = read_csv(STUDENT_FILE)

        students.append({
            "student_id": sid,
            "name": name,
            "email": email,
            "enrolled_courses": ""
        })

        write_csv(
            STUDENT_FILE,
            ["student_id", "name", "email", "enrolled_courses"],
            students
        )

        print("Student registered successfully")

    def enroll_course(self):

        sid = input("Enter Student ID : ")
        cid = input("Enter Course ID : ")

        students = read_csv(STUDENT_FILE)
        courses = read_csv(COURSE_FILE)

        student = None
        course = None

        for s in students:
            if s["student_id"] == sid:
                student = s

        if student is None:
            raise StudentNotFound("Student not found")

        for c in courses:
            if c["course_id"] == cid:
                course = c

        if course is None:
            raise CourseNotFound("Course not found")

        if int(course["seats_available"]) == 0:
            raise CourseFull("No seats available")

        enrolled = []

        if student["enrolled_courses"] != "":
            enrolled = student["enrolled_courses"].split(";")

        if cid not in enrolled:
            enrolled.append(cid)

        student["enrolled_courses"] = ";".join(enrolled)

        course["seats_available"] = str(int(course["seats_available"]) - 1)

        write_csv(
            STUDENT_FILE,
            ["student_id", "name", "email", "enrolled_courses"],
            students
        )

        write_csv(
            COURSE_FILE,
            ["course_id", "course_name", "instructor", "seats_available"],
            courses
        )

        print("Course enrollment successful")

    def drop_course(self):

        sid = input("Student ID : ")
        cid = input("Course ID : ")

        students = read_csv(STUDENT_FILE)
        courses = read_csv(COURSE_FILE)

        student = None
        course = None

        for s in students:
            if s["student_id"] == sid:
                student = s

        if student is None:
            raise StudentNotFound("Student not found")

        for c in courses:
            if c["course_id"] == cid:
                course = c

        if course is None:
            raise CourseNotFound("Course not found")

        enrolled = []

        if student["enrolled_courses"]:
            enrolled = student["enrolled_courses"].split(";")

        if cid in enrolled:
            enrolled.remove(cid)

        student["enrolled_courses"] = ";".join(enrolled)

        course["seats_available"] = str(int(course["seats_available"]) + 1)

        write_csv(
            STUDENT_FILE,
            ["student_id", "name", "email", "enrolled_courses"],
            students
        )

        write_csv(
            COURSE_FILE,
            ["course_id", "course_name", "instructor", "seats_available"],
            courses
        )

        print("Course dropped successfully")