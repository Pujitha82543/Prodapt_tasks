class CourseNotFound(Exception):
    pass


class StudentNotFound(Exception):
    pass


class CourseFull(Exception):
    pass