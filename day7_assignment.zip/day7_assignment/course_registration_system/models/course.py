class Course:
    def __init__(self, course_id, course_name, instructor, seats_available):
        self.course_id = course_id
        self.course_name = course_name
        self.instructor = instructor
        self.seats_available = int(seats_available)

    def to_list(self):
        return [
            self.course_id,
            self.course_name,
            self.instructor,
            str(self.seats_available)
        ]
    
    