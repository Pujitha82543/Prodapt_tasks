class Student:

    def __init__(self, student_id, name, email, enrolled_courses=""):
        self.student_id = student_id
        self.name = name
        self.email = email
        self.enrolled_courses = enrolled_courses

    def get_courses(self):
        if self.enrolled_courses == "":
            return []
        return self.enrolled_courses.split(";")

    def set_courses(self, courses):
        self.enrolled_courses = ";".join(courses)

    def to_list(self):
        return [
            self.student_id,
            self.name,
            self.email,
            self.enrolled_courses
        ]