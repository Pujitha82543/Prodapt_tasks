const api = require("../services/api");

// Display Post
function display(posts) {
    posts.forEach(post => {
        console.log("--------------------------------");
        console.log("ID :", post.id);
        console.log("Username :", post.username);
        console.log("Content :", post.content);
        console.log("Category :", post.category);
        console.log("Likes :", post.likes);
        console.log("Hashtag :", post.hashtags);
        console.log("--------------------------------");
    });
}

// Activity 1
async function viewAllPosts() {
    const res = await api.get("/");
    display(res.data);
}

// Activity 2
async function viewSinglePost(id) {
    const res = await api.get(`/${id}`);
    display([res.data]);
}

// Activity 3
async function createPost() {

    const post = {
        username: "sophia",
        content: "Node.js APIs are awesome!",
        category: "Programming",
        likes: 0,
        hashtags: "#nodejs"
    };

    await api.post("/", post);

    console.log("Post Created Successfully");
}

// Activity 4
async function updatePost(id) {

    const res = await api.get(`/${id}`);

    const post = {
        ...res.data,
        likes: 150,
        content: "Morning workout completed successfully!",
        category: "Health"
    };

    await api.put(`/${id}`, post);

    console.log("Post Updated Successfully");
}

// Activity 5
async function deletePost(id) {

    await api.delete(`/${id}`);

    console.log("Post Deleted Successfully");
}

// Activity 6
async function searchByUsername(username) {

    const res = await api.get(`?username=${username}`);

    display(res.data);
}

// Activity 7
async function searchByHashtag(tag) {

    const res = await api.get(`?hashtags=${tag}`);

    display(res.data);
}

// Activity 8
async function filterCategory(category) {

    const res = await api.get(`?category=${category}`);

    display(res.data);
}

// Activity 9
async function sortLikes() {

    const res = await api.get("?_sort=likes&_order=desc");

    display(res.data);
}

// Activity 10
async function trendingPosts() {

    const res = await api.get("?_sort=likes&_order=desc&_limit=3");

    display(res.data);
}

// Activity 11
async function searchContent(word) {

    const res = await api.get(`?q=${word}`);

    display(res.data);
}

// Activity 12
async function popularPosts() {

    const res = await api.get("?likes_gte=100");

    display(res.data);
}

// Activity 13
async function latestPosts() {

    const res = await api.get("?_sort=id&_order=desc&_limit=5");

    display(res.data);
}

// Activity 14
async function likePost(id) {

    const res = await api.get(`/${id}`);

    console.log("Before Likes :", res.data.likes);

    res.data.likes++;

    await api.put(`/${id}`, res.data);

    console.log("After Likes :", res.data.likes);
}

// Activity 15
async function searchAndFilter() {

    const res = await api.get("?username=john&category=Programming");

    display(res.data);
}

module.exports = {

    viewAllPosts,
    viewSinglePost,
    createPost,
    updatePost,
    deletePost,
    searchByUsername,
    searchByHashtag,
    filterCategory,
    sortLikes,
    trendingPosts,
    searchContent,
    popularPosts,
    latestPosts,
    likePost,
    searchAndFilter

};