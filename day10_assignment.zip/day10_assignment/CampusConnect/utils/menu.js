function menu() {

    console.log("===== CampusConnect =====");

    console.log("1. View All Posts");
    console.log("2. View Single Post");
    console.log("3. Create Post");
    console.log("4. Update Post");
    console.log("5. Delete Post");
    console.log("6. Search Username");
    console.log("7. Search Hashtag");
    console.log("8. Filter Category");
    console.log("9. Sort Likes");
    console.log("10. Trending Posts");
    console.log("11. Search Content");
    console.log("12. Popular Posts");
    console.log("13. Latest Posts");
    console.log("14. Like Post");
    console.log("15. Search + Filter");

}

module.exports = menu;