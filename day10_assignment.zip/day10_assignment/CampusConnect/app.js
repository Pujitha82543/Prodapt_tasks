const post = require("./controllers/postController");

async function run() {

    console.log("\nActivity 1");
    await post.viewAllPosts();

    console.log("\nActivity 2");
    await post.viewSinglePost(3);

    console.log("\nActivity 3");
    await post.createPost();

    console.log("\nActivity 4");
    await post.updatePost(2);

    console.log("\nActivity 5");
    await post.deletePost(4);

    console.log("\nActivity 6");
    await post.searchByUsername("john");

    console.log("\nActivity 7");
    await post.searchByHashtag("#AI");

    console.log("\nActivity 8");
    await post.filterCategory("Programming");

    console.log("\nActivity 9");
    await post.sortLikes();

    console.log("\nActivity 10");
    await post.trendingPosts();

    console.log("\nActivity 11");
    await post.searchContent("JavaScript");

    console.log("\nActivity 12");
    await post.popularPosts();

    console.log("\nActivity 13");
    await post.latestPosts();

    console.log("\nActivity 14");
    await post.likePost(1);

    console.log("\nActivity 15");
    await post.searchAndFilter();

}

run();