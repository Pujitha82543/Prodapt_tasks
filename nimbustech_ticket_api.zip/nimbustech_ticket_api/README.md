# NimbusTech Ticket API

## Create Virtual Environment

```bash
python -m venv venv
```

Windows

```bash
venv\Scripts\activate
```

Install Packages

```bash
pip install -r requirements.txt
```

Generate Report

```bash
python -m ticket_processor.main --input data/tickets_raw.csv --output data/tickets_report.json
```

Run API

```bash
uvicorn ticket_api.main:app --reload
```

Swagger

```
http://127.0.0.1:8000/docs
```