"""
Main entry point for ticket processing.
"""

import argparse
import logging
import sys

from ticket_processor.processor import process_tickets


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)


def main():
    """
    Main function.
    """

    parser = argparse.ArgumentParser(
        description="NimbusTech Ticket Processor"
    )

    parser.add_argument(
        "--input",
        required=True,
        help="Input CSV file"
    )

    parser.add_argument(
        "--output",
        required=True,
        help="Output JSON file"
    )

    args = parser.parse_args()

    try:

        logging.info("Processing started")

        report = process_tickets(
            args.input,
            args.output
        )

        logging.info("Processing completed")

        logging.info(
            "Valid Tickets : %s",
            report["summary"]["valid_tickets"]
        )

        logging.info(
            "Invalid Rows : %s",
            report["summary"]["invalid_rows"]
        )

    except Exception as error:

        logging.error(error)

        sys.exit(1)


if __name__ == "__main__":
    main()