"""
Pydantic model for FastAPI.
"""

from dataclasses import dataclass


@dataclass
class Ticket:
    ticket_id: str
    customer_name: str
    category: str
    priority_raw: str
    priority_score: int
    created_at: str
    sla_hours: int
    status: str
    sla_breached: bool