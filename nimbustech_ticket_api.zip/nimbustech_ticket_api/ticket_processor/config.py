"""
Configuration constants.
"""

PRIORITY_MAP = {
    "low": 1,
    "medium": 2,
    "high": 3,
    "critical": 4
}

INVALID_ABORT_RATIO = 0.60

DATE_FORMAT = "%Y-%m-%d %H:%M:%S"