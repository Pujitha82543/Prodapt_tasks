from datetime import datetime
from ticket_processor.config import DATE_FORMAT, PRIORITY_MAP


def validate_row(row):
    """Validate a ticket row."""

    if not row["ticket_id"].strip():
        return False, "Missing ticket_id"

    if not row["customer_name"].strip():
        return False, "Missing customer_name"

    if row["priority_raw"].lower() not in PRIORITY_MAP:
        return False, "Invalid priority"

    try:
        sla = int(row["sla_hours"])
        if sla <= 0:
            return False, "Invalid sla_hours"
    except ValueError:
        return False, "Invalid sla_hours"

    try:
        datetime.strptime(row["created_at"], DATE_FORMAT)
    except ValueError:
        return False, "Invalid created_at"

    return True, ""