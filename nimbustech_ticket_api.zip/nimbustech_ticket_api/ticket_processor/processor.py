"""
Ticket processing functions.
"""

import csv
import json
from collections import defaultdict
from datetime import datetime, timedelta

from ticket_processor.config import (
    DATE_FORMAT,
    INVALID_ABORT_RATIO,
    PRIORITY_MAP,
)
from ticket_processor.models import Ticket
from ticket_processor.validators import validate_row


def process_tickets(input_file, output_file):
    """
    Read CSV, validate rows,
    calculate SLA, generate JSON report.
    """

    valid_tickets = []
    invalid_rows = []
    category_count = defaultdict(int)

    with open(input_file, "r", newline="", encoding="utf-8") as csv_file:
        reader = csv.DictReader(csv_file)

        rows = list(reader)

    total_rows = len(rows)

    for row in rows:

        valid, reason = validate_row(row)

        if not valid:
            invalid_rows.append(
                {
                    "raw_row": row,
                    "reason": reason
                }
            )
            continue

        created = datetime.strptime(
            row["created_at"],
            DATE_FORMAT
        )

        sla_time = created + timedelta(
            hours=int(row["sla_hours"])
        )

        breached = (
            datetime.now() > sla_time
            and row["status"].lower() != "closed"
        )

        ticket = Ticket(
            ticket_id=row["ticket_id"],
            customer_name=row["customer_name"],
            category=row["category"],
            priority_raw=row["priority_raw"],
            priority_score=PRIORITY_MAP[
                row["priority_raw"].lower()
            ],
            created_at=row["created_at"],
            sla_hours=int(row["sla_hours"]),
            status=row["status"],
            sla_breached=breached
        )

        valid_tickets.append(ticket.__dict__)

        category_count[row["category"]] += 1

    invalid_ratio = len(invalid_rows) / total_rows if total_rows else 0

    if invalid_ratio > INVALID_ABORT_RATIO:
        raise Exception(
            "Processing aborted. "
            "Invalid rows exceed 10%."
        )

    report = {
        "generated_at": datetime.now().isoformat(),

        "summary": {
            "total_rows": total_rows,
            "valid_tickets": len(valid_tickets),
            "invalid_rows": len(invalid_rows),
            "breached_count": sum(
                ticket["sla_breached"]
                for ticket in valid_tickets
            ),
            "by_category": dict(category_count)
        },

        "tickets": valid_tickets,

        "invalid_rows": invalid_rows
    }

    with open(
        output_file,
        "w",
        encoding="utf-8"
    ) as json_file:

        json.dump(
            report,
            json_file,
            indent=4
        )

    return report