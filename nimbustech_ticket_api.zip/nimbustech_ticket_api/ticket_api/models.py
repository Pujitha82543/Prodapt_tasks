"""
Pydantic model for FastAPI.
"""

from pydantic import BaseModel


class TicketRequest(BaseModel):
    ticket_id: str
    customer_name: str
    category: str
    priority_raw: str
    created_at: str
    sla_hours: int
    status: str