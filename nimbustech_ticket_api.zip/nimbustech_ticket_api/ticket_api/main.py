"""
FastAPI application.
"""

from fastapi import FastAPI, HTTPException

from ticket_api.models import TicketRequest
from ticket_api.store import load_data, tickets

app = FastAPI(
    title="NimbusTech Ticket API"
)

load_data()


@app.get("/")
def home():

    return {
        "status": "ok",
        "service": "ticket-triage-api"
    }


@app.get("/tickets")
def get_all():

    return tickets


@app.get("/tickets/breached")
def get_breached():

    return [
        ticket
        for ticket in tickets
        if ticket["sla_breached"]
    ]


@app.get("/tickets/{ticket_id}")
def get_ticket(ticket_id: str):

    for ticket in tickets:

        if ticket["ticket_id"] == ticket_id:
            return ticket

    raise HTTPException(
        status_code=404,
        detail="Ticket not found"
    )


@app.post("/tickets")
def add_ticket(ticket: TicketRequest):

    tickets.append(ticket.dict())

    return {
        "message": "Ticket Added"
    }


@app.put("/tickets/{ticket_id}")
def update_ticket(
        ticket_id: str,
        ticket: TicketRequest
):

    for index, value in enumerate(tickets):

        if value["ticket_id"] == ticket_id:

            tickets[index] = ticket.dict()

            return {
                "message": "Ticket Updated"
            }

    raise HTTPException(
        status_code=404,
        detail="Ticket not found"
    )


@app.delete("/tickets/{ticket_id}")
def delete_ticket(ticket_id: str):

    for ticket in tickets:

        if ticket["ticket_id"] == ticket_id:

            tickets.remove(ticket)

            return {
                "message": "Ticket Deleted"
            }

    raise HTTPException(
        status_code=404,
        detail="Ticket not found"
    )