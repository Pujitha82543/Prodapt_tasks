"""
Loads ticket data into memory.
"""

import json


tickets = []


def load_data():
    """
    Load tickets from JSON report.
    """

    global tickets

    with open(
        "data/tickets_report.json",
        "r",
        encoding="utf-8"
    ) as file:

        report = json.load(file)

    tickets = report["tickets"]