const BASE_URL = "https://fakestoreapi.com";

module.exports = BASE_URL;