const axios = require("axios");
const BASE_URL = require("../config/api");

async function addProduct() {

    const product = {
        title: "Python Programming Book",
        price: 499,
        description: "Learn Python from beginner to advanced",
        image: "https://i.pravatar.cc",
        category: "books"
    };

    try {

        const response = await axios.post(`${BASE_URL}/products`, product);

        console.log("\n===== PRODUCT ADDED =====\n");
        console.log(response.data);

    } catch (error) {
        console.log(error.message);
    }

}

module.exports = addProduct;