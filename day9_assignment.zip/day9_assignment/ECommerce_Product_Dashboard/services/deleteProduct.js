const axios = require("axios");
const BASE_URL = require("../config/api");

async function deleteProduct() {

    try {

        const response = await axios.delete(`${BASE_URL}/products/1`);

        console.log("\n===== PRODUCT DELETED =====\n");
        console.log(response.data);

    } catch (error) {
        console.log(error.message);
    }

}

module.exports = deleteProduct;