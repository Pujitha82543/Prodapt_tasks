const axios = require("axios");
const BASE_URL = require("../config/api");

async function getProducts() {
    try {
        const response = await axios.get(`${BASE_URL}/products`);

        console.log("\n===== ALL PRODUCTS =====\n");

        response.data.forEach(product => {
            console.log(`ID       : ${product.id}`);
            console.log(`Title    : ${product.title}`);
            console.log(`Price    : ₹${product.price}`);
            console.log(`Category : ${product.category}`);
            console.log("-------------------------------");
        });

    } catch (error) {
        console.log(error.message);
    }
}

module.exports = getProducts;