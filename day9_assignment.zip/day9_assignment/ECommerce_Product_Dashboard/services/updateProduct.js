const axios = require("axios");
const BASE_URL = require("../config/api");

async function updateProduct() {

    const updatedProduct = {
        title: "Python Programming Book - Second Edition",
        price: 599,
        description: "Updated edition with FastAPI",
        image: "https://i.pravatar.cc",
        category: "books"
    };

    try {

        const response = await axios.put(
            `${BASE_URL}/products/1`,
            updatedProduct
        );

        console.log("\n===== PRODUCT UPDATED =====\n");
        console.log(response.data);

    } catch (error) {
        console.log(error.message);
    }

}

module.exports = updateProduct;