const getProducts = require("./services/getProducts");
const addProduct = require("./services/addProduct");
const updateProduct = require("./services/updateProduct");
const deleteProduct = require("./services/deleteProduct");

async function main() {

    console.log("\n========= E-Commerce Product Dashboard =========\n");

    console.log("Activity 1");
    await getProducts();

    console.log("\nActivity 2");
    await addProduct();

    console.log("\nActivity 3");
    await updateProduct();

    console.log("\nActivity 4");
    await deleteProduct();

}

main();