from typing import Callable

# -------------------------------
# Part 4 : Callable
# -------------------------------

Notification = Callable[[str, str], None]


def email_notification(member_name: str, message: str) -> None:
    print(f"\n📧 Email sent to {member_name}")
    print(f"Message : {message}")


def sms_notification(member_name: str, message: str) -> None:
    print(f"\n📱 SMS sent to {member_name}")
    print(f"Message : {message}")


def whatsapp_notification(member_name: str, message: str) -> None:
    print(f"\n💬 WhatsApp sent to {member_name}")
    print(f"Message : {message}")