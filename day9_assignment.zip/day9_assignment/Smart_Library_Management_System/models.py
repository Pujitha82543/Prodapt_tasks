from typing import TypedDict, Union

# -------------------------------
# Part 1 : TypedDict
# -------------------------------

class Book(TypedDict):
    book_id: int
    title: str
    author: str
    publication_year: int
    category: str
    available: bool


# -------------------------------
# Part 2 : Union
# -------------------------------

MemberID = Union[int, str]


def display_member(member_id: MemberID) -> None:
    print(f"Member ID : {member_id}")