from typing import Sequence

from models import Book, display_member
from notifications import (
    email_notification,
    sms_notification,
    whatsapp_notification,
    Notification,
)

# -------------------------------------
# Sample Books (TypedDict)
# -------------------------------------

book1: Book = {
    "book_id": 101,
    "title": "Python Programming",
    "author": "Guido van Rossum",
    "publication_year": 2023,
    "category": "Programming",
    "available": True,
}

book2: Book = {
    "book_id": 102,
    "title": "Data Structures",
    "author": "Mark Allen",
    "publication_year": 2021,
    "category": "Computer Science",
    "available": False,
}

book3: Book = {
    "book_id": 103,
    "title": "Machine Learning",
    "author": "Andrew Ng",
    "publication_year": 2022,
    "category": "AI",
    "available": True,
}


# -------------------------------------
# Part 3 : Sequence
# -------------------------------------

def display_books(books: Sequence[Book]) -> None:
    print("\nAvailable Books\n")

    for book in books:
        if book["available"]:
            print(f"Title  : {book['title']}")
            print(f"Author : {book['author']}")
            print("-" * 30)


# -------------------------------------
# Issue / Return Book
# -------------------------------------

def issue_book(member_name: str,
               message: str,
               notify: Notification) -> None:
    notify(member_name, message)


# -------------------------------------
# Main Program
# -------------------------------------

print("====== SMART LIBRARY MANAGEMENT SYSTEM ======\n")

print("Student Member")
display_member(1001)

print()

print("Faculty Member")
display_member("FAC-205")

# List
books_list = [book1, book2, book3]

display_books(books_list)

# Tuple
books_tuple = (book1, book2, book3)

display_books(books_tuple)

print("\nNotification Examples")

issue_book(
    "Pujitha",
    "Your book has been issued successfully.",
    email_notification
)

issue_book(
    "Rahul",
    "Your book has been returned successfully.",
    sms_notification
)

issue_book(
    "Anitha",
    "Please collect your reserved book.",
    whatsapp_notification
)