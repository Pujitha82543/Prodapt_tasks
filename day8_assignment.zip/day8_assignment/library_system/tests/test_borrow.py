from services.borrow_service import BorrowService
from models.member import Member
from models.book import Book
from models.borrow_record import BorrowRecord

member = Member(1, "Pujitha", 22, "Premium")

book = Book(101, "Python", "Guido", "Programming")

record = BorrowRecord(1001, member, book, "17-07-2026")

service = BorrowService()

service.borrow_book(record)

assert book.is_available == False

service.return_book(1001, "20-07-2026")

assert book.is_available == True

print("Borrow Test Passed")