from services.book_service import BookService
from models.book import Book

service = BookService()

book = Book(101, "Python", "Guido", "Programming")

service.add_book(book)

assert service.get_book(101).title == "Python"

print("Book Test Passed")