from models.member import Member
from models.book import Book
from models.borrow_record import BorrowRecord

from services.library_system import LibrarySystem

library = LibrarySystem()

# Add Member
member = Member(1, "Pujitha", 22, "Premium")
library.member_service.add_member(member)

# Add Books
book1 = Book(101, "Python Basics", "Guido", "Programming")
book2 = Book(102, "Data Structures", "Narasimha", "Computer Science")

library.book_service.add_book(book1)
library.book_service.add_book(book2)

# Display Members
print("\nMembers")
library.member_service.display_members()

# Display Books
print("\nBooks")
library.book_service.display_books()

# Borrow Book
record = BorrowRecord(1001, member, book1, "17-07-2026")
library.borrow_service.borrow_book(record)

print("\nBorrow Records")
library.borrow_service.display_records()

print("\nBooks After Borrow")
library.book_service.display_books()

# Return Book
library.borrow_service.return_book(1001, "20-07-2026")

print("\nBooks After Return")
library.book_service.display_books()