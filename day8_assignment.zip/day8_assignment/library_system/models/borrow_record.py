class BorrowRecord:

    def __init__(self, borrow_id, member, book, borrow_date):
        self.borrow_id = borrow_id
        self.member = member
        self.book = book
        self.borrow_date = borrow_date
        self.return_date = None

    def __str__(self):
        return f"BorrowID:{self.borrow_id}, Member:{self.member.name}, Book:{self.book.title}, Borrow:{self.borrow_date}, Return:{self.return_date}"