class Book:

    def __init__(self, book_id, title, author, genre):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.is_available = True

    def __str__(self):
        status = "Available" if self.is_available else "Borrowed"

        return f"ID:{self.book_id}, Title:{self.title}, Author:{self.author}, Genre:{self.genre}, Status:{status}"