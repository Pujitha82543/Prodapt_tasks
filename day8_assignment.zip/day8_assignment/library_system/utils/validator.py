def valid_membership(membership):

    return membership.lower() in ["regular", "premium"]


def book_available(book):

    return book.is_available