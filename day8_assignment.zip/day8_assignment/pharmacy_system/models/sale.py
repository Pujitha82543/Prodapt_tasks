class Sale:

    def __init__(self, sale_id, customer, medicine, quantity, date):
        self.sale_id = sale_id
        self.customer = customer
        self.medicine = medicine
        self.quantity = quantity
        self.date = date
        self.total_amount = medicine.price * quantity

    def __str__(self):
        return f"SaleID:{self.sale_id}, Customer:{self.customer.name}, Medicine:{self.medicine.name}, Quantity:{self.quantity}, Date:{self.date}, Total:{self.total_amount}"