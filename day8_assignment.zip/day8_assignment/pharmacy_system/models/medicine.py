class Medicine:

    def __init__(self, medicine_id, name, medicine_type, price, quantity):
        self.medicine_id = medicine_id
        self.name = name
        self.medicine_type = medicine_type
        self.price = price
        self.quantity = quantity

    def __str__(self):
        return f"ID:{self.medicine_id}, Name:{self.name}, Type:{self.medicine_type}, Price:{self.price}, Stock:{self.quantity}"