datastore = {
    "customers": {},
    "medicines": {},
    "sales": {}
}