from models.customer import Customer
from models.medicine import Medicine
from models.sale import Sale

from services.pharmacy_system import PharmacySystem

pharmacy = PharmacySystem()

# Add Customer
customer = Customer(1, "Pujitha", 22, "Paracetamol")
pharmacy.customer_service.add_customer(customer)

# Add Medicines
medicine1 = Medicine(101, "Paracetamol", "Tablet", 20, 100)
medicine2 = Medicine(102, "Amoxicillin", "Capsule", 50, 50)

pharmacy.medicine_service.add_medicine(medicine1)
pharmacy.medicine_service.add_medicine(medicine2)

# Display Customers
print("\nCustomers")

for customer in pharmacy.customer_service.get_customer(1),:
    print(customer)

# Display Medicines
print("\nMedicines")
pharmacy.medicine_service.display_medicines()

# Create Sale
sale = Sale(1001, customer, medicine1, 5, "17-07-2026")
pharmacy.sale_service.create_sale(sale)

# Display Sales
print("\nSales")
pharmacy.sale_service.display_sales()

# Medicines After Sale
print("\nMedicines After Sale")
pharmacy.medicine_service.display_medicines()