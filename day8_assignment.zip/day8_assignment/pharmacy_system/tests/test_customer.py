from services.customer_service import CustomerService
from models.customer import Customer

service = CustomerService()

customer = Customer(1, "Pujitha", 22, "Paracetamol")

service.add_customer(customer)

assert service.get_customer(1).name == "Pujitha"

print("Customer Test Passed")