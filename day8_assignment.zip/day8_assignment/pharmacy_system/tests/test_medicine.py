from services.medicine_service import MedicineService
from models.medicine import Medicine

service = MedicineService()

medicine = Medicine(101, "Paracetamol", "Tablet", 20, 100)

service.add_medicine(medicine)

assert service.get_medicine(101).name == "Paracetamol"

print("Medicine Test Passed")